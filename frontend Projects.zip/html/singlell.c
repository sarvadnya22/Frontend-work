#include <stdio.h>
#include <stdlib.h>
void insertatbeg();
void insertatend();
void insertatmid();
void deleteatfront();
 void deleteatend();
 void deleteatmid();
void display();
struct node
{
int val;
struct node *next;
};
struct node *head,*temp;

void main ()
{
    int choice=0;
    printf("\n Singly linked list\n");
    
    while(choice != 8)
    {
        printf("\n\nChose one from the below options...\n");
        printf("\n1.insert at front\n4.insert at end\n6.insertat middle\n5.delete at end\n2.delete at front\n7.delete at middle\n3.display\n8.exit");
        printf("\n Enter your choice \n");
        scanf("%d",&choice);
        switch(choice)
        {
            case 1:
            {
                 insertatbeg();
                break;
            }
            case 2:
            {
                 deleteatfront();
                break;
            }
            case 3:
            {
                display();
                break;
            }
            case 4:
            {
                insertatend();break;
            }
            case 5:{
                  deleteatend();break;
            }
            case 6:{
                insertatmid();break;
            }
            case 7:{
                deleteatmid();break;
            }
            default:
            {
                printf("Please Enter valid choice ");
            }
    };
}
}
void insertatbeg()
{
    int val;
    struct node *ptr = (struct node*)malloc(sizeof(struct node));
    if(ptr == NULL)
    {
        printf("not able to push the element");
    }
    else
    {
        printf("Enter the value");
        scanf("%d",&val);
        if(head==NULL)
        {
            ptr->val = val;
            ptr -> next = NULL;
            head=ptr;
        }
        else
        {
            ptr->val = val;
            ptr->next = head;
            head=ptr;

        }
        printf("Item pushed");

    }
}
void insertatend(){
    int val;
    struct node *ptr = (struct node*)malloc(sizeof(struct node));
     if(ptr == NULL)
    {
        printf("not able to push the element");
    }
    else
    {
        printf("Enter the value");
        scanf("%d",&val);
        if(head==NULL)
        {
            ptr->val = val;
            ptr -> next = NULL;
            head=ptr;
        }
        else{ptr->val = val;
            ptr -> next = NULL;
             temp=head;
            while(temp->next!=NULL){
                temp=temp->next;
            }temp->next=ptr;
        }
}
}
void insertatmid(){
    int item;
     if (head == NULL)
    {
        printf("no node present");
    }
    else{
        int val1;
    struct node *ptr = (struct node*)malloc(sizeof(struct node));
    if(ptr == NULL)
    {
        printf("not able to push the element");
    }
    else{
        printf("\nenter the element after that you want t insert");
        scanf("%d",&val1);
         printf("\nenter the element  you want t insert");
        scanf("%d",&item);
        ptr->val=item;
        ptr->next=NULL;
        temp=head;
        while(temp->val!=val1){
            temp=temp->next;
        }
        temp->next=ptr->next=temp->next;
        temp->next=NULL;
        temp->next=ptr;
        
        
    }
    }
    
}
void deleteatfront()
{
    int item;
    struct node *ptr;
    if (head == NULL)
    {
        printf("Underflow");
    }
    else
    {
        item = head->val;
        ptr = head;
        head = head->next;
        free(ptr);
        printf("Item popped %d",item);

    }
}
void deleteatend(){
     int x;
    
    if (head == NULL)
    {
        printf("Underflow");
    } 
    if(head->next==NULL){
        x=head->val;
        head=NULL;
        printf("pop last is %d",x);
    }
    else{
        temp=head;
        while((temp->next->next)!=NULL){
       temp=temp->next;
    }x=temp->next->val;
    temp->next=NULL;
    printf("pop last is %d",x);
}
}
void deleteatmid(){
     int i,x,item;
     
     if (head == NULL)
    {
        printf("no node present");
    }
     printf("enter the position do you want to delete");
        scanf("%d",&x); 
    if(x==1){
item=head->val;


printf("\ndelete from mid %d",item);
    }
    else{
       
        temp=head;
        while(i!=x-2){
            temp=temp->next;
            i++;}
            item=temp->next->val;
        temp->next=temp->next->next;
        printf("\ndelete from mid %d",item);
    }
}
void display()
{
    int i;
    struct node *ptr;
    ptr=head;
    if(ptr == NULL)
    {
        printf("Stack is empty\n");
    }
    else
    {
        printf("Printing Stack elements \n");
        while(ptr!=NULL)
        {
            printf("%d\n",ptr->val);
            ptr = ptr->next;
        }
    }
}
